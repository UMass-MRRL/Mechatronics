# MIE 443 DC Motor Designer MATLAB v2.5

## Quick start: ONE MATLAB FILE

This version fixes two reported MATLAB startup errors:

```
Unrecognized function or variable 'DCMotorPresets'.
Error in DCMotorDesignerMATLAB (line 11)

Unrecognized property 'Units' for class 'matlab.ui.control.TextArea'.
```

**The GUI is self-contained and now uses a responsive grid layout for the metrics text area.** The five required helpers (`DCMotorPresets`,
`DCMotorModel`, `DCMotorResponse`, `DCMotorSensitivity`, and
`DCMotorEquations`) are all included as **local functions in
`DCMotorDesignerMATLAB.m`**. You can run it after downloading only that
single file.

1. Download `DCMotorDesignerMATLAB.m` to a folder on your computer.
2. In MATLAB, set **Current Folder** to the folder containing that file.
3. Type:

   ```matlab
   clear DCMotorDesignerMATLAB
   DCMotorDesignerMATLAB
   ```

`clear` is optional, but helps when overwriting a prior version in the
same MATLAB session.

If you still see an error, check which file MATLAB is executing:

```matlab
which DCMotorDesignerMATLAB -all
```

The correct path should point to this new `DCMotorDesignerMATLAB.m`.
If it points to an older file, change the MATLAB Current Folder or remove
the old location from the path.

**Requires base MATLAB with App Designer graphics support.** Simulink is not
required for the interactive GUI. Recommended MATLAB R2023b or newer. The
native MATLAB interface has **not been executed in this authoring environment**,
so report any remaining GUI-specific errors with the line number.

## Optional: Simulink and numerical testing

The ZIP includes separate copies of the model functions so the independent
Simulink model generator and numerical test script can call them. They are
**not required for the GUI**.

For an editable plant block diagram, with Simulink installed:

```matlab
build_DCMotor_Simulink_Advanced
```

To run numerical consistency tests:

```matlab
test_DCMotorDesigner
```

These optional commands do require **all `.m` files from the ZIP together**
in the MATLAB Current Folder or on its path. The standalone GUI resolves its
own local helper copies first. Simulink is an intentionally reduced
voltage-mode dynamics model, not a full GUI equivalent.

## Model and educational disclaimer

**EDUCATIONAL USE ONLY.** This is a simplified, first-principles brushed DC
motor teaching simulator. Numerical values are model predictions and have not
been experimentally validated for any named commercial motor. The physical
drawings are schematics. It is **not** a reliable basis for component selection,
thermal ratings, electrical safety decisions, or real motor design.

The model assumes an ideal magnetic circuit, simplified motor geometries,
constant gearbox efficiency, lumped thermal nodes, and no brush loss or
iron saturation. The voltage-drive model retains inductance and signed
armature current; the ideal-current-mode approximation omits current-loop
transients.

## Contents

- `DCMotorDesignerMATLAB.m` : **one-file GUI**, contains all its own helper functions.
- `DCMotorPresets.m` : optional external helper for testing/model generator.
- `DCMotorModel.m` : optional external model helper.
- `DCMotorResponse.m` : optional external transient helper.
- `DCMotorSensitivity.m` : optional external sensitivity helper.
- `DCMotorEquations.m` : optional external equation-text helper.
- `build_DCMotor_Simulink_Advanced.m` : optional Simulink generator.
- `test_DCMotorDesigner.m` : optional numerical checks.

## v2.4 MATLAB UI correction (October 21, 2026)

- Removed the invalid `metrics.Units='normalized'` assignment from the `uitextarea`.
- Replaced fixed pixel text positioning with `uigridlayout` inside the metrics panel.
- Normalized several `GridLayout.Padding` assignments to documented four-value vectors.
- No App Designer toolbox is required: `uifigure`, `uitextarea`, `uislider`, and
  `uigridlayout` are provided by base MATLAB.

**Verification limitation:** Changes were checked statically against MathWorks UI
API documentation and source layout. This environment cannot run MATLAB, so
full native GUI startup and animation remain unverified.

## Classic torque-speed diagram (v2.4)

On the **Motor & Performance** tab, the large upper performance chart now
plots **available output torque (mN·m) vertically** versus **output speed
(rpm) horizontally**. It marks the idealized stall torque (0 rpm), no-load
speed (0 external torque), and the selected operating point. A pinned reference
design is dashed. With current control, the characteristic can be piecewise;
the curve is not a continuous-duty envelope. The three lower panels continue
to plot current, power, and efficiency versus applied output torque.

This revision preserves the v2.2 model and UI structure, but its modified
MATLAB visualization has not been executed in MATLAB by the preparer.


## Torque-speed graph (v2.4)

The primary plot holds speed and torque axis limits fixed to 2.25 times the
starting preset's no-load speed and stall torque. A dotted baseline stays
visible as sliders change. `Auto-fit axes` expands the scale to include the
current design, baseline, pinned reference, and requested torque load.
`Reset baseline` captures the current design and starts a fresh comparison.
The red dashed horizontal line indicates demanded torque. A stalled operating
point is flagged as an unmet demand rather than plotted as an achievable point.

The two motor governing equations are unchanged from v2.3. The new UI has
been structurally checked, but cannot be verified by running native MATLAB
in this environment. Test in MATLAB before distributing the ZIP to students.

## v2.5 changes: shared speed axis

The main torque-speed graph and three supporting plots now use the same **output-speed (rpm)** horizontal coordinate. The supporting views are current (A), mechanical output power (W) and efficiency (%). Locked/Auto-fit affects their common RPM range. Dashed pinned references, dotted startup baseline, and operating speed markers remain visible. Peak power and efficiency are also marked. Winding and thermal models have not changed.

The updated MATLAB GUI has been reviewed structurally but was **not executed in MATLAB** in this environment. Base MATLAB is needed for the GUI; Simulink is optional.


### Flywheel assumption (v2.6)

Flywheel is a solid steel disk (rho=7850 kg/m^3) attached to the gearbox output shaft. The app now displays disk mass (g), output inertia (g cm^2), motor-reflected inertia (g cm^2, equal to J_load/Ng^2), and total motor-side inertia. At Ng=1 the two flywheel inertias are equal. Gear inertia, hub mass, and acceleration-dependent gearbox losses are excluded. This is an educational idealization.


## v2.6.1 graph cleanup

Fixed accumulating operating-point circles, peak markers, and vertical speed
lines in MATLAB plots when changing parameters. MATLAB `cla` did not delete
objects created with `HandleVisibility=off`; the GUI now calls
`delete(allchild(ax))` before redraw. Equations are unchanged. This fix is
source-reviewed but has not been executed in native MATLAB here.
