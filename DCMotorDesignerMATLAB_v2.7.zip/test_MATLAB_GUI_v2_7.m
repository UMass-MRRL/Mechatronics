function test_MATLAB_GUI_v2_7()
% Run in MATLAB with UI testing support; use after extracting all .m files.
% Does NOT validate physical accuracy against measured motors.
DCMotorDesignerMATLAB;
drawnow;
fig=findall(groot,'Tag','MIE443_DCMotorDesigner');
assert(numel(fig)==1,'Motor app did not launch.');
cleanup=onCleanup(@()close(fig));
tc=matlab.uitest.TestCase.forInteractiveUse;
preset=findall(fig,'Tag','PresetSelector');
resetDesign=findall(fig,'Tag','ResetDesignToPreset');
pin=findall(fig,'Tag','PinReference');
voltage=findall(fig,'Tag','Parameter_V');
assert(numel(voltage)==1 && numel(resetDesign)==1);
% Change voltage, then reset without changing the preset selection.
voltage.Value=20;
voltage.ValueChangedFcn(voltage,[]);
assert(abs(voltage.Value-20)<1e-9);
tc.press(resetDesign);
assert(abs(voltage.Value-12)<1e-9,'Reset to preset failed.');
% Pin Hobby then switch to N20: explicit comparison must not leak across presets.
tc.press(pin);
assert(strcmp(pin.Text,'Ref pinned'));
tc.choose(preset,'N20');
assert(strcmp(pin.Text,'Pin reference'),'Preset switch did not clear pinned reference.');
assert(abs(voltage.Value-5)<1e-9);
tc.choose(preset,'Hobby');
assert(abs(voltage.Value-12)<1e-9);
% Rapid motor response must animate at a visible pace, not end immediately.
play=findall(fig,'Tag','MotorPlayback');
tc.press(play);
pause(0.2);drawnow;
assert(strcmp(play.Text,'Pause'),'Playback ended prematurely.');
tc.press(play);
fprintf('MATLAB UI smoke test PASS: preset reset, reference clear, playback.\n');
end
