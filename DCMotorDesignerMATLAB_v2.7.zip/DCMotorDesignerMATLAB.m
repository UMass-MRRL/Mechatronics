function DCMotorDesignerMATLAB()
% DCMotorDesignerMATLAB  Visual motor-design teaching lab, MIE 443.
%
% Run: >> DCMotorDesignerMATLAB
% Requires base MATLAB with App Designer UI components (recommended R2023b+).
% No Simulink required. This file now includes all GUI model helpers.
% Copy ONLY DCMotorDesignerMATLAB.m to a new folder to run the GUI.
% Standalone build v2.7, 2026-10-22 (UI still requires MATLAB runtime testing).
% EDUCATIONAL ONLY. Not suitable for motor selection or hardware ratings.

red=[136 28 28]/255; copper=[181 101 29]/255;
blue=[44 95 176]/255; muted=[.40 .45 .52]; bg=[.95 .96 .975];
p=DCMotorPresets('Hobby'); c=[];s=[]; rp=[]; rc=[];rs=[]; bc=[]; tsAxisLimits=[];
playing=false; tplay=0; lastTick=[]; rotAngle=0; hWind=[];
cursorSpeed=[];cursorCurrent=[];cursorHeat=[];
controlHandles=struct();

fig=uifigure('Name','MIE 443 | DC Motor Designer MATLAB v2.7',...
    'Position',[55 50 1590 930],'Color',bg);
fig.CloseRequestFcn=@closeLab;
fig.Tag='MIE443_DCMotorDesigner';
root=uigridlayout(fig,[2 2]);root.RowHeight={76,'1x'};
root.ColumnWidth={356,'1x'};root.Padding=[10 10 10 10];
root.RowSpacing=10;root.ColumnSpacing=12;

head=uigridlayout(root,[2 1]);head.Layout.Row=1;head.Layout.Column=[1 2];
head.RowHeight={38,23};head.Padding=[18 6 18 6];head.RowSpacing=1;
head.BackgroundColor=red;
h1=uilabel(head,'Text','DC MOTOR DESIGNER  |  MATLAB',...
    'FontWeight','bold','FontSize',25,'FontColor',[1 1 1]);h1.Layout.Row=1;
h2=uilabel(head,'Text',...
    'Explore winding, geometry, magnets, gearing, torque-speed, electrical dynamics and heat',...
    'FontSize',12,'FontColor',[1 1 1]);h2.Layout.Row=2;

left=uipanel(root,'Title','DESIGN PARAMETERS','FontWeight','bold',...
    'BackgroundColor',[1 1 1]);left.Layout.Row=2;left.Layout.Column=1;
leftGrid=uigridlayout(left,[3 1]);leftGrid.RowHeight={151,'1x',48};
leftGrid.Padding=[6 6 6 6];leftGrid.RowSpacing=4;
bar=uigridlayout(leftGrid,[4 3]);bar.Layout.Row=1;
bar.RowHeight={25,31,31,31};bar.ColumnWidth={'1x','1x','1x'};
bar.Padding=[4 0 4 0];bar.ColumnSpacing=4;
preset=uidropdown(bar,'Items',{'Hobby','N20','Neo'},'Value','Hobby',...
    'ValueChangedFcn',@loadPreset);preset.Layout.Row=1;preset.Layout.Column=[1 2];
preset.Tag='PresetSelector';
pinBtn=uibutton(bar,'Text','Pin reference','ButtonPushedFcn',@pinReference);
pinBtn.Layout.Row=1;pinBtn.Layout.Column=3;
pinBtn.Tag='PinReference';
playBtn=uibutton(bar,'Text','Play','BackgroundColor',red,'FontColor',[1 1 1],...
    'ButtonPushedFcn',@togglePlay);playBtn.Layout.Row=2;playBtn.Layout.Column=1;
playBtn.Tag='MotorPlayback';
resetBtn=uibutton(bar,'Text','Restart','ButtonPushedFcn',@restart);
resetBtn.Layout.Row=2;resetBtn.Layout.Column=2;
unpinBtn=uibutton(bar,'Text','Clear ref','ButtonPushedFcn',@clearReference);
unpinBtn.Layout.Row=2;unpinBtn.Layout.Column=3;
% Torque-speed axes are fixed against a captured starting baseline by default.
% Users may auto-fit or reset the baseline without changing the motor model.
scaleMode=uidropdown(bar,'Items',{'Locked axes','Auto-fit axes'},...
    'Value','Locked axes','ValueChangedFcn',@changeTSScale);
scaleMode.Layout.Row=3;scaleMode.Layout.Column=[1 2];
baselineBtn=uibutton(bar,'Text','Reset baseline','ButtonPushedFcn',@resetTSBaseline);
baselineBtn.Layout.Row=3;baselineBtn.Layout.Column=3;
resetDesignBtn=uibutton(bar,'Text','Reset design to preset',...
    'ButtonPushedFcn',@resetDesignToPreset);
resetDesignBtn.Layout.Row=4;resetDesignBtn.Layout.Column=[1 3];
resetDesignBtn.Tag='ResetDesignToPreset';

% The long list scrolls; parameter groups follow the web-based designer.
fields={...
    'GROUP','DRIVE / CONTROL','','',0,0;...
    'SELECT','drive','Drive mode','Voltage|Current',0,0;...
    'SLIDER','V','Supply voltage (V)','',1,48;...
    'SLIDER','Icmd','Commanded current (A)','',.01,60;...
    'GROUP','WINDING','','',0,0;...
    'SLIDER','N','Total turns N','',10,3000;...
    'SLIDER','dw','Wire diameter (mm)','',.02,2;...
    'SELECT','m','Coils (3/5/7: same average)','1|3|5|7',0,0;...
    'GROUP','ROTOR GEOMETRY','','',0,0;...
    'SLIDER','d','Rotor diameter (mm)','',3,60;...
    'SLIDER','l','Active length (mm)','',4,120;...
    'GROUP','MAGNETS','','',0,0;...
    'SELECT','mat','Magnet material','Ferrite|NdFeB',0,0;...
    'SLIDER','hm','Magnet thickness (mm)','',.5,12;...
    'SLIDER','g','Air gap (mm)','',.1,3;...
    'SLIDER','T','R, Br reference temp (C)','',20,150;...
    'GROUP','FRICTION','','',0,0;...
    'SLIDER','b','Viscous drag (micro N m s/rad)','',0,200;...
    'GROUP','GEARHEAD & LOAD (steel flywheel)','','',0,0;...
    'SLIDER','Ng','Gear ratio Ng','',1,300;...
    'SLIDER','eta','Gear efficiency (%)','',40,100;...
    'SLIDER','rL','Flywheel radius (mm)','',0,60;...
    'SLIDER','tL','Flywheel thickness (mm)','',0,20;...
    'SLIDER','tauL','Opposing torque (mN m)','',0,3000};
controlPanel=uipanel(leftGrid,'BorderType','none','BackgroundColor',[1 1 1]);
controlPanel.Layout.Row=2;
ng=size(fields,1);g=uigridlayout(controlPanel,[ng 1]);rowSizes=cell(1,ng);
g.Padding=[8 4 8 6];g.RowSpacing=2;g.Scrollable='on';
for n=1:ng
    type=fields{n,1};key=fields{n,2};caption=fields{n,3};
    if strcmp(type,'GROUP')
        rowSizes{n}=30;
        lab=uilabel(g,'Text',key,'FontWeight','bold','FontSize',12,...
            'FontColor',red);lab.Layout.Row=n;
    elseif strcmp(type,'SELECT')
        rowSizes{n}=41;
        gg=uigridlayout(g,[1 2]);gg.Layout.Row=n;
        gg.ColumnWidth={'1x',128};gg.Padding=[0 0 0 0];
        lb=uilabel(gg,'Text',caption,'FontSize',11);lb.Layout.Column=1;
        options=strsplit(fields{n,4},'|');
        if strcmp(key,'m'),v=num2str(p.m);else,v=p.(key);end
        dropdown=uidropdown(gg,'Items',options,'Value',v,...
            'ValueChangedFcn',@(src,~)changeSelect(key,src.Value));
        dropdown.Tag=['Parameter_' key];
        dropdown.Layout.Column=2;
        controlHandles.(key)=struct('type','select','dropdown',dropdown);
    else
        rowSizes{n}=65;
        gg=uigridlayout(g,[2 2]);gg.Layout.Row=n;
        gg.RowHeight={23,27};gg.ColumnWidth={'1x',76};
        gg.RowSpacing=0;gg.ColumnSpacing=5;gg.Padding=[0 0 0 0];
        lb=uilabel(gg,'Text',caption,'FontSize',11);
        lb.Layout.Row=1;lb.Layout.Column=1;
        edit=uieditfield(gg,'numeric','Limits',[fields{n,5},fields{n,6}],...
            'Value',p.(key),'ValueChangedFcn',@(src,~)changeNumber(key,src.Value));
        edit.Tag=['Parameter_' key];
        edit.Layout.Row=1;edit.Layout.Column=2;
        slide=uislider(gg,'Limits',[fields{n,5},fields{n,6}],...
            'Value',p.(key),'ValueChangedFcn',@(src,~)changeNumber(key,src.Value));
        slide.MajorTicks=[fields{n,5},fields{n,6}];slide.MinorTicks=[];
        slide.Layout.Row=2;slide.Layout.Column=[1 2];
        controlHandles.(key)=struct('type','slider','edit',edit,'slide',slide);
    end
end

right=uitabgroup(root);right.Layout.Row=2;right.Layout.Column=2;
tDesign=uitab(right,'Title','Motor & Performance');
tDynamics=uitab(right,'Title','Transients & Heating');
tSensitivity=uitab(right,'Title','Sensitivity');
tEquations=uitab(right,'Title','Equation Inspector');

% Motor + performance: dimension-scaled drawings and classic torque versus speed.
% All performance graphs use output RPM on X, including current, power and efficiency.
vgrid=uigridlayout(tDesign,[2 1]);vgrid.RowHeight={330,'1x'};
vgrid.RowSpacing=8;vgrid.Padding=[8 8 8 8];
top=uigridlayout(vgrid,[1 3]);top.Layout.Row=1;
top.ColumnWidth={'1x','1x',270};top.Padding=[0 0 0 0];
axEnd=newAxis(top,1,1,'ROTOR / AIR GAP / MAGNETS (SCHEMATIC)');
axSide=newAxis(top,1,2,'MOTOR / FLYWHEEL (GEAR SCHEMATIC)');
metricsPanel=uipanel(top,'Title','IDEALIZED DESIGN OUTPUTS','FontWeight','bold');
metricsPanel.Layout.Column=3;
% UI TextArea has no Units property. Use a grid layout so the results
% resize with their containing panel (compatible with base MATLAB).
metricsGrid=uigridlayout(metricsPanel,[1 1]);
metricsGrid.Padding=[5 5 5 5];
metrics=uitextarea(metricsGrid,'Editable','off','FontName','Consolas',...
    'FontSize',11);
metrics.Layout.Row=1;metrics.Layout.Column=1;
% Full-width conventional characteristic followed by three RPM-indexed views.
perf=uigridlayout(vgrid,[2 6]);perf.Layout.Row=2;
perf.ColumnWidth={'1x','1x','1x','1x','1x','1x'};
perf.RowHeight={'1.3x','1x'};
perf.Padding=[0 0 0 0];perf.RowSpacing=6;perf.ColumnSpacing=8;
axTS=newAxis(perf,1,[1 6],'CLASSIC TORQUE vs SPEED (OUTPUT SHAFT)');
axIT=newAxis(perf,2,[1 2],'CURRENT vs OUTPUT SPEED');
axPT=newAxis(perf,2,[3 4],'POWER vs OUTPUT SPEED');
axET=newAxis(perf,2,[5 6],'EFFICIENCY vs OUTPUT SPEED');

% Dynamics tab: preserve signed current, and show separate winding/housing.
dyngrid=uigridlayout(tDynamics,[2 2]);dyngrid.RowHeight={'1x','1x'};
dyngrid.ColumnWidth={'1x','1x'};dyngrid.Padding=[8 8 8 8];
axSpeed=newAxis(dyngrid,1,1,'OUTPUT SPEED / STARTUP');
axCurrent=newAxis(dyngrid,1,2,'ARMATURE CURRENT (SIGNED)');
axTw=newAxis(dyngrid,2,1,'WINDING TEMPERATURE (FULL HISTORY)');
axTh=newAxis(dyngrid,2,2,'HOUSING TEMPERATURE (FULL HISTORY)');

% Sensitivity: normalized log derivatives, not experimental uncertainties.
sensgrid=uigridlayout(tSensitivity,[2 1]);sensgrid.RowHeight={'1x',115};
sensgrid.Padding=[10 10 10 10];
axSens=uiaxes(sensgrid);axSens.Layout.Row=1;
sensNotes=uitextarea(sensgrid,'Editable','off','FontSize',12,...
    'Value',{'S = d ln(output) / d ln(input).  A +2 means 1% input change produces about 2% output change locally.','The colored cells are predictions of this simplified model, not measured sensitivities.','Finite differences use +/-1% at the current design.'});
sensNotes.Layout.Row=2;

% Equation browser keeps equations readable without hunting through tooltips.
eqgrid=uigridlayout(tEquations,[3 1]);eqgrid.RowHeight={44,'1x',115};
eqgrid.Padding=[18 18 18 18];
eqBox=uidropdown(eqgrid,'Items',{'Field and magnets','Torque and back EMF',...
    'Winding resistance','Inductance','Inertia and gearing',...
    'Steady speed and torque','Electrical-mechanical dynamics',...
    'Efficiency and power','Thermal network'},...
    'ValueChangedFcn',@equationChanged);eqBox.Layout.Row=1;
eqText=uitextarea(eqgrid,'Editable','off','FontName','Consolas',...
    'FontSize',15);eqText.Layout.Row=2;
eqInfo=uitextarea(eqgrid,'Editable','off','FontSize',11,'Value',...
    {'These are model equations, not measured datasheet correlations.',...
    'Magnet flux ignores leakage and iron saturation.',...
    'Copper R and magnet Br are frozen at the temperature slider setting.',...
    'Click the magnets or rotor in the end view to open a relevant equation.'});
eqInfo.Layout.Row=3;

g.RowHeight=rowSizes;
footerBar=uigridlayout(leftGrid,[1 2]);footerBar.Layout.Row=3;
footerBar.ColumnWidth={'1x','1x'};footerBar.Padding=[0 0 0 0];
% Footer grid and note share a row only if explicitly nested.
note=uilabel(footerBar,'Text','EDUCATIONAL / THEORETICAL ONLY',...
    'FontSize',10,'FontColor',red,'WordWrap','on');
note.Layout.Row=1;note.Layout.Column=1;
exportBtn=uibutton(footerBar,'Text','Export CSV','ButtonPushedFcn',@exportCSV);
exportBtn.Layout.Row=1;exportBtn.Layout.Column=2;

animTimer=timer('ExecutionMode','fixedSpacing','Period',0.05,...
    'BusyMode','drop','TimerFcn',@tick);
refresh();

    function ax=newAxis(parent,row,col,heading)
        pan=uipanel(parent,'Title',heading,'FontWeight','bold');
        pan.Layout.Row=row;pan.Layout.Column=col;
        gl=uigridlayout(pan,[1 1]);gl.Padding=[10 5 10 7];
        ax=uiaxes(gl);ax.Layout.Row=1;ax.Layout.Column=1;
        ax.FontSize=10;ax.Box='on';
    end

    function changeTSScale(~,~)
        drawPerformance();
    end
    function resetTSBaseline(~,~)
        % Capture the current construction as the new dotted baseline.
        bc=c;
        tsAxisLimits=[max(1,2.25*c.w0/c.Ng*60/(2*pi)),...
                      max(1,2.25*c.stallOut*1e3)];
        drawPerformance();
    end
    function loadPreset(src,~)
        % A preset switch resets the design and explicitly clears reference.
        pausePlayback();p=DCMotorPresets(src.Value);bc=[];tsAxisLimits=[];
        rp=[];rc=[];rs=[];pinBtn.Text='Pin reference';
        syncControls();refresh();
    end
    function resetDesignToPreset(~,~)
        % Reapply preset even if the preset dropdown has not changed.
        loadPreset(preset,[]);
    end
    function changeSelect(key,value)
        if strcmp(key,'m'),p.m=str2double(value);else,p.(key)=char(value);end
        refresh();
    end
    function changeNumber(key,val)
        if strcmp(key,'N')||strcmp(key,'Ng'),val=round(val);end
        p.(key)=val;
        handles=controlHandles.(key);
        handles.edit.Value=val;handles.slide.Value=val;
        refresh();
    end
    function syncControls()
        keys=fieldnames(controlHandles);
        for k=1:numel(keys)
            key=keys{k};h=controlHandles.(key);
            if strcmp(h.type,'slider')
                h.slide.Value=p.(key);h.edit.Value=p.(key);
            elseif strcmp(key,'m')
                h.dropdown.Value=num2str(p.m);
            else
                h.dropdown.Value=p.(key);
            end
        end
    end
    function refresh()
        pausePlayback();c=DCMotorModel(p);s=DCMotorResponse(c);
        if isempty(bc)
            bc=c;
            tsAxisLimits=[max(1,2.25*c.w0/c.Ng*60/(2*pi)),...
                          max(1,2.25*c.stallOut*1e3)];
        end
        tplay=0;rotAngle=0;
        drawEnd();drawSide();drawMetrics();drawPerformance();drawDynamics();drawSensitivity();
        equationChanged([],[]);updateAnimation();
    end
    function pinReference(~,~)
        rp=p;rc=c;rs=s;pinBtn.Text='Ref pinned';refresh();
    end
    function clearReference(~,~)
        rp=[];rc=[];rs=[];pinBtn.Text='Pin reference';refresh();
    end
    function drawEnd()
        cla(axEnd);hold(axEnd,'on');
        r=p.d/2;r1=r+p.g;r2=r1+p.hm;
        outer=c.Dout*1e3/2;
        if ~isempty(rc)
            rr=rc.Dout*1e3/2;
            th=linspace(0,2*pi,150);
            plot(axEnd,rr*cos(th),rr*sin(th),'--','Color',[.48 .53 .59]);
        end
        th=linspace(0,2*pi,200);
        plot(axEnd,outer*cos(th),outer*sin(th),'Color',[.47 .51 .56],...
            'LineWidth',5,'ButtonDownFcn',@(~,~)setEquation('Thermal network'));
        for k=1:2
            if k==1,ang=linspace(-pi/3,pi/3,70);col=blue;
            else,ang=linspace(2*pi/3,4*pi/3,70);col=red;end
            x=[r1*cos(ang),r2*cos(fliplr(ang))];
            y=[r1*sin(ang),r2*sin(fliplr(ang))];
            patch(axEnd,x,y,col,'EdgeColor','none','FaceAlpha',.85,...
                'ButtonDownFcn',@(~,~)setEquation('Field and magnets'));
        end
        patch(axEnd,r*cos(th),r*sin(th),[.78 .81 .85],...
            'EdgeColor',[.36 .41 .46],'ButtonDownFcn',...
            @(~,~)setEquation('Inertia and gearing'));
        for yy=linspace(-r*.60,r*.60,5)
            span=sqrt(max(0,r^2-yy^2));
            plot(axEnd,[-span,span],[yy,yy],':','Color',[.52 .57 .62]);
        end
        coilRadius=.84*r;
        angles=rotAngle+(0:2*p.m-1)*pi/p.m;
        hWind=plot(axEnd,coilRadius*cos(angles),coilRadius*sin(angles),'o',...
            'MarkerSize',9,'MarkerFaceColor',copper,'MarkerEdgeColor','w',...
            'ButtonDownFcn',@(~,~)setEquation('Torque and back EMF'));
        plot(axEnd,0,0,'.','MarkerSize',19,'Color',[.20 .23 .28]);
        text(axEnd,-r2,0,'N','Color','w','FontWeight','bold',...
            'HorizontalAlignment','center');
        text(axEnd,r2,0,'S','Color','w','FontWeight','bold',...
            'HorizontalAlignment','center');
        lim=1.14*max(outer,~isempty(rc)*getRefRadius());
        xlim(axEnd,[-lim,lim]);ylim(axEnd,[-lim,lim]);axis(axEnd,'equal');
        xlabel(axEnd,'mm');ylabel(axEnd,'mm');grid(axEnd,'off');hold(axEnd,'off');
    end
    function radius=getRefRadius()
        radius=0;if ~isempty(rc),radius=rc.Dout*1e3/2;end
    end
    function drawSide()
        cla(axSide);hold(axSide,'on');
        Lm=c.Lout*1e3;Dm=c.Dout*1e3;
        patch(axSide,[0 Lm Lm 0],[-Dm/2 -Dm/2 Dm/2 Dm/2],...
            [.69 .73 .78],'EdgeColor',[.35 .40 .46],...
            'ButtonDownFcn',@(~,~)setEquation('Thermal network'));
        patch(axSide,[4 p.l+4 p.l+4 4],...
            [-p.d/2 -p.d/2 p.d/2 p.d/2],[.85 .75 .58],...
            'EdgeColor',copper,'ButtonDownFcn',@(~,~)setEquation('Winding resistance'));
        x=Lm; if p.Ng>1
            w=.8*Dm;
            patch(axSide,[x x+w x+w x],[-Dm*.45 -Dm*.45 Dm*.45 Dm*.45],...
                [.40 .45 .53],'EdgeColor','none',...
                'ButtonDownFcn',@(~,~)setEquation('Inertia and gearing'));
            text(axSide,x+w/2,0,sprintf('%.0f:1',p.Ng),'Color','w',...
                'FontWeight','bold','HorizontalAlignment','center');
            x=x+w;
        end
        shaft=max(5,.25*Dm);
        patch(axSide,[x x+shaft x+shaft x],[-1.2 -1.2 1.2 1.2],...
            [.32 .35 .39],'EdgeColor','none');x=x+shaft;
        if p.rL>0 && p.tL>0
            patch(axSide,[x x+p.tL x+p.tL x],...
                [-p.rL -p.rL p.rL p.rL],[.58 .64 .71],...
                'EdgeColor',[.24 .28 .33],...
                'ButtonDownFcn',@(~,~)setEquation('Inertia and gearing'));
        end
        text(axSide,0,Dm*.67,sprintf('Motor D %.1f mm, L %.1f mm',Dm,Lm),...
            'FontSize',9);
        lim=max(Dm/2,p.rL)*1.6;
        xlim(axSide,[-6,max(x+p.tL+6,35)]);ylim(axSide,[-lim lim]);
        xlabel(axSide,'Axial length (mm)');ylabel(axSide,'Radius (mm)');
        grid(axSide,'off');hold(axSide,'off');
    end
    function drawMetrics()
        notes={...
            sprintf('B       %9.3f T',c.B),...
            sprintf('Kt, Ke  %9.4g SI',c.Kt),...
            sprintf('R       %9.4g ohm',c.R),...
            sprintf('L       %9.4g mH',c.L*1e3),...
            sprintf('Stall I %9.4g A',c.stallI),...
            sprintf('Stall T %9.4g mN m',c.stallOut*1e3),...
            sprintf('Speed   %9.0f rpm',c.wss/c.Ng*60/(2*pi)),...
            sprintf('I(load) %9.4g A',c.iss),...
            sprintf('Eff(load) %7.1f %%',100*c.eff),...
            sprintf('Max P   %9.4g W',max(c.curPower)),...
            sprintf('Fly: solid steel, rho 7850 kg/m^3'),...
            sprintf('Fly mass %9.4g g',c.mFly*1e3),...
            sprintf('Fly Jout %9.4g g cm2',c.JL*1e7),...
            sprintf('Fly Jref %9.4g g cm2 (Ng=%g)',c.JloadReflected*1e7,c.Ng),...
            sprintf('J total at motor %9.4g g cm2',c.J*1e7),...
            sprintf('Slot fill %7.1f %%',100*c.fill),...
            sprintf('tauE    %9.3g ms',c.tauE*1e3),...
            sprintf('tauEff  %9.3g ms',c.tauEff*1e3),...
            sprintf('Tw est. %9.0f C',c.Twss),...
            sprintf('Drive: %s',c.region),...
            sprintf('Coils 3/5/7 share averaged Kt, R, L'),...
            sprintf('Heating starts 25 C; material T = %.0f C',p.T)};
        if ~isempty(rc)
            notes{end+1}=sprintf('Ref Kt: %.4g; ref rpm: %.0f',rc.Kt,rc.wss/rc.Ng*60/(2*pi));
        end
        if c.fill>.55,notes{end+1}='WARNING: winding does not fit';end
        if c.Twss>130,notes{end+1}='HIGH modeled thermal rise';end
        metrics.Value=notes;
    end
    function drawPerformance()
        % One shared physical axis scale. The dotted starting-design curve
        % is always visible, even without an explicitly pinned reference.
        % Remove all old graphics, INCLUDING markers and xlines created
        % with HandleVisibility='off'. Ordinary cla() preserves those
        % objects and otherwise leaves misleading markers on redraw.
        delete(allchild(axTS));hold(axTS,'on');
        hBase=plot(axTS,flip(bc.curSpeed),flip(bc.curTorque),':',...
            'Color',muted,'LineWidth',1.8,'DisplayName','Starting baseline');
        if ~isempty(rc)
            plot(axTS,flip(rc.curSpeed),flip(rc.curTorque),'--',...
                'Color',blue,'LineWidth',1.7,'DisplayName','Pinned reference');
        end
        plot(axTS,flip(c.curSpeed),flip(c.curTorque),'-',...
            'Color',copper,'LineWidth',2.6,'DisplayName','Current design');
        stallmNm=c.stallOut*1e3;
        noLoadRPM=c.w0/c.Ng*60/(2*pi);
        opRPM=c.wss/c.Ng*60/(2*pi);
        requested=p.tauL;
        if strcmp(scaleMode.Value,'Auto-fit axes')
            maxRPM=max([noLoadRPM,bc.w0/bc.Ng*60/(2*pi),1]);
            maxTorque=max([stallmNm,bc.stallOut*1e3,requested,1]);
            if ~isempty(rc)
                maxRPM=max(maxRPM,rc.w0/rc.Ng*60/(2*pi));
                maxTorque=max(maxTorque,rc.stallOut*1e3);
            end
            graphX=1.12*maxRPM;graphY=1.13*maxTorque;
        else
            graphX=tsAxisLimits(1);graphY=tsAxisLimits(2);
        end
        % Horizontal red load line is the torque demand, not the motor's
        % continuous rating. Mark a stalled/unsatisfied demand with an X.
        if requested>0 && requested<=graphY
            yline(axTS,requested,'--','Color',red,'LineWidth',1.4,...
                'DisplayName','Requested load');
        end
        plot(axTS,[0 noLoadRPM],[stallmNm 0],'o','MarkerSize',5,...
            'MarkerFaceColor',muted,'MarkerEdgeColor','w','HandleVisibility','off');
        if strcmp(c.region,'Stalled')
            if requested<=graphY
                plot(axTS,0,requested,'x','Color',red,'MarkerSize',11,...
                    'LineWidth',2,'DisplayName','Unmet load');
            end
        else
            plot(axTS,opRPM,requested,'o','MarkerSize',9,...
                'MarkerFaceColor',red,'MarkerEdgeColor','w',...
                'DisplayName','Operating point');
            xline(axTS,opRPM,':','Color',muted,'HandleVisibility','off');
        end
        xlabel(axTS,'Output speed (rpm)');ylabel(axTS,'Available output torque (mN m)');
        xlim(axTS,[0 graphX]);ylim(axTS,[0 graphY]);
        isClipped=max([noLoadRPM,~isempty(rc)*getRefMaxSpeed()])>graphX ||...
            max([stallmNm,requested,~isempty(rc)*getRefMaxTorque()])>graphY;
        if isClipped && strcmp(scaleMode.Value,'Locked axes')
            title(axTS,'AXES LOCKED: curve/load clipped. Use Auto-fit or Reset baseline.',...
                'Color',red,'FontSize',10);
        elseif strcmp(c.region,'Stalled')
            title(axTS,sprintf('STALL: demanded %.3g > available %.3g mN m',requested,stallmNm),...
                'Color',red,'FontSize',10);
        else
            title(axTS,sprintf('Stall %.3g mN m | No-load %.0f rpm | Load %.3g mN m',...
                stallmNm,noLoadRPM,requested),'FontSize',10);
        end
        legend(axTS,'show','Location','northeast','FontSize',8);
        grid(axTS,'on');hold(axTS,'off');

        % All steady-state plots use output speed on the horizontal axis.
        % One graphX is shared with torque-speed, including the Locked and
        % Auto-fit settings. The starting baseline is plotted in each view.
        axesList={axIT,axPT,axET};
        yFields={'curCurrent','curPower','curEff'};
        yLabels={'Current (A)','Mechanical output power (W)','Efficiency (%)'};
        for j=1:3
            a=axesList{j};field=yFields{j};delete(allchild(a));hold(a,'on');
            plot(a,bc.curSpeed,bc.(field),':','Color',muted,...
                'LineWidth',1.4,'DisplayName','Starting baseline');
            if ~isempty(rc)
                plot(a,rc.curSpeed,rc.(field),'--','Color',blue,...
                    'LineWidth',1.5,'DisplayName','Pinned reference');
            end
            plot(a,c.curSpeed,c.(field),'-','Color',copper,...
                'LineWidth',2,'DisplayName','Current design');
            if ~strcmp(c.region,'Stalled')
                switch j
                    case 1, yy=c.iss;
                    case 2, yy=c.Pout;
                    otherwise, yy=100*c.eff;
                end
                plot(a,opRPM,yy,'o','MarkerSize',7,...
                    'MarkerFaceColor',red,'MarkerEdgeColor','w',...
                    'HandleVisibility','off');
                xline(a,opRPM,':','Color',muted,'HandleVisibility','off');
            end
            if j==2 || j==3
                [~,peakIdx]=max(c.(field));
                curveValues=c.(field);
                plot(a,c.curSpeed(peakIdx),curveValues(peakIdx),'ko',...
                    'MarkerSize',5,'HandleVisibility','off');
            end
            xlabel(a,'Output speed (rpm)');ylabel(a,yLabels{j});
            xlim(a,[0 graphX]);
            candidates=[max(c.(field)),max(bc.(field))];
            if ~isempty(rc),candidates(end+1)=max(rc.(field));end
            if j==3
                ylim(a,[0 100]);
            else
                basePeak=max(bc.(field));
                if j==2,scale=5;else,scale=2.25;end
                lockMax=max(eps,basePeak*scale);
                if strcmp(scaleMode.Value,'Auto-fit axes')
                    ylimit=max(eps,1.12*max(candidates));
                else
                    ylimit=lockMax;
                end
                ylim(a,[0 ylimit]);
                if max(candidates)>ylimit && strcmp(scaleMode.Value,'Locked axes')
                    title(a,'Vertical scale clipped: select Auto-fit',...
                        'Color',red,'FontSize',9);
                end
            end
            grid(a,'on');hold(a,'off');
        end
    end
    function v=getRefMaxSpeed()
        v=0;if ~isempty(rc),v=rc.w0/rc.Ng*60/(2*pi);end
    end
    function v=getRefMaxTorque()
        v=0;if ~isempty(rc),v=max(rc.curTorque);end
    end
    function drawDynamics()
        aList={axSpeed,axCurrent,axTw,axTh};
        times={s.t,s.t,s.thermalT,s.thermalT};
        fields={'rpm','current','Tw','Th'};
        labels={'Output speed (rpm)','Motor current (A)',...
            'Winding node (C)','Housing node (C)'};
        for j=1:4
            a=aList{j};delete(allchild(a));hold(a,'on');
            if ~isempty(rs)
                if j<=2,rt=rs.t;else,rt=rs.thermalT;end
                plot(a,rt,rs.(fields{j}),'--','Color',[.52 .57 .63]);
            end
            plot(a,times{j},s.(fields{j}),'-','Color',...
                ternary(j==2,copper,blue),'LineWidth',2);
            if j==2,yline(a,0,':');end
            if j==3,yline(a,130,'--','Example threshold','Color',red);end
            if j<=2,xx=s.Tspeed;else,xx=s.Tthermal;end
            xlim(a,[0 max(xx,eps)]);
            xlabel(a,'Time (s)');ylabel(a,labels{j});
            if j==1,cursorSpeed=xline(a,0,'--','Color',red);end
            if j==2,cursorCurrent=xline(a,0,'--','Color',red);end
            % Thermal graphs show their full physical time axis; no startup
            % playback cursor is drawn on a much longer heating timeline.
            grid(a,'on');hold(a,'off');
        end
    end
    function out=ternary(condition,aa,bb)
        if condition,out=aa;else,out=bb;end
    end
    function drawSensitivity()
        [S,rNames,cNames]=DCMotorSensitivity(p);
        cla(axSens);
        h=imagesc(axSens,S);h.AlphaData=isfinite(S);
        axSens.XTick=1:numel(cNames);axSens.XTickLabel=cNames;
        axSens.YTick=1:numel(rNames);axSens.YTickLabel=rNames;
        axSens.XTickLabelRotation=35;
        axSens.YDir='normal';clim(axSens,[-4 4]);
        colormap(axSens,parula(256));colorbar(axSens);
        title(axSens,'LOCAL LOG SENSITIVITY (model only)');
        for i=1:size(S,1)
            for j=1:size(S,2)
                if isfinite(S(i,j))
                    text(axSens,j,i,sprintf('%+.1f',S(i,j)),...
                        'Color',[.08 .1 .14],'HorizontalAlignment','center','FontSize',9);
                end
            end
        end
    end
    function equationChanged(~,~)
        eqText.Value=DCMotorEquations(c,eqBox.Value);
    end
    function setEquation(which)
        eqBox.Value=which;equationChanged([],[]);right.SelectedTab=tEquations;
    end
    function exportCSV(~,~)
        % Save ALL inputs needed to reproduce this design, plus predictions.
        [name,path]=uiputfile('dc_motor_design.csv','Export motor predictions');
        if isequal(name,0),return;end
        tbl=struct2table(p,'AsArray',true);
        tbl.ModelVersion="2.7";
        tbl.B_T=c.B; tbl.Kt_NmPerA=c.Kt; tbl.R_ohm=c.R;
        tbl.L_H=c.L; tbl.J_motor_kgm2=c.J; tbl.FillRatio=c.fill;
        tbl.StallTorque_mNm=c.stallOut*1e3;
        tbl.LoadedSpeed_rpm=c.wss/c.Ng*60/(2*pi);
        tbl.LoadedCurrent_A=c.iss;tbl.LoadedEfficiency_pct=100*c.eff;
        tbl.ModeledWindingSteady_C=c.Twss;
        tbl.Convection_Wm2K=1.32*(50/c.Dout)^.25+6;
        tbl.ModelNotes="25 C thermal start; R and Br frozen at selected T";
        writetable(tbl,fullfile(path,name));
    end
    function togglePlay(~,~)
        if playing,pausePlayback();return;end
        if tplay>=s.Tspeed,tplay=0;rotAngle=0;end
        lastTick=tic;playing=true;playBtn.Text='Pause';
        if strcmp(animTimer.Running,'off'),start(animTimer);end
    end
    function restart(~,~)
        pausePlayback();tplay=0;rotAngle=0;updateAnimation();
    end
    function pausePlayback()
        playing=false;playBtn.Text='Play';
        if exist('animTimer','var') && isvalid(animTimer) && strcmp(animTimer.Running,'on')
            stop(animTimer);
        end
    end
    function tick(~,~)
        if ~isvalid(fig),return;end
        try
            dt=min(.15,toc(lastTick));lastTick=tic;
            % Playback always spans about 8 wall-clock seconds, even for
            % 0.1-second motor startups; tplay remains physical model time.
            tplay=min(s.Tspeed,tplay+dt*s.Tspeed/8);
            j=find(s.t<=tplay,1,'last');if isempty(j),j=1;end
            w=s.wMotor(j);
            rotAngle=rotAngle+sign(w)*min(abs(w),2*pi*.8)*dt;
            updateAnimation();
            if tplay>=s.Tspeed,pausePlayback();end
        catch ME
            warning('DCMotorDesignerMATLAB:Animation','%s',ME.message);
            pausePlayback();
        end
    end
    function updateAnimation()
        if isgraphics(hWind)
            r=.84*p.d/2;
            aa=rotAngle+(0:2*p.m-1)*pi/p.m;
            hWind.XData=r*cos(aa);hWind.YData=r*sin(aa);
        end
        if isgraphics(cursorSpeed),cursorSpeed.Value=tplay;end
        if isgraphics(cursorCurrent),cursorCurrent.Value=tplay;end
        % Thermal histories are deliberately not scrubbed by startup playback.
        j=find(s.t<=tplay,1,'last');if isempty(j),j=1;end
        fig.Name=sprintf('MIE 443 DC Motor | t %.3g s | %.0f rpm | %.3g A',...
            tplay,s.rpm(j),s.current(j));
    end
    function closeLab(~,~)
        try
            pausePlayback();delete(animTimer);
        catch
        end
        delete(fig);
    end
end


% =======================================================================
% LOCAL HELPER: DCMotorPresets.m
% Included so the GUI runs without extra files or MATLAB path setup.
% =======================================================================
function p = DCMotorPresets(which)
% DCMotorPresets  Parameter sets matching the MIE 443 web motor designer.
if nargin<1,which='Hobby';end
p=struct('drive','Voltage','V',12,'Icmd',2,'N',240,'dw',.25,...
    'm',3,'d',16,'l',25,'mat','Ferrite','hm',3,'g',.5,'T',25,...
    'b',2,'Ng',1,'eta',100,'rL',25,'tL',5,'tauL',10);
switch lower(char(which))
    case {'hobby','12 v ferrite'}
    case {'n20','n20 gearmotor'}
        p.N=260;p.dw=.10;p.d=7;p.l=10;p.hm=1.5;p.g=.3;
        p.V=5;p.Icmd=.5;p.b=.05;p.Ng=100;p.eta=60;
        p.rL=20;p.tL=4;p.tauL=5;
    case {'neo','ndfeb 30 mm'}
        p.N=120;p.dw=.42;p.m=7;p.d=22;p.l=40;p.mat='NdFeB';
        p.hm=3;p.g=.5;p.V=24;p.Icmd=10;p.b=5;p.Ng=1;
        p.eta=100;p.rL=30;p.tL=6;p.tauL=20;
    otherwise
        error('Unknown preset: %s',char(which));
end
end


% =======================================================================
% LOCAL HELPER: DCMotorModel.m
% Included so the GUI runs without extra files or MATLAB path setup.
% =======================================================================
function c = DCMotorModel(p)
% DCMotorModel  Geometry-based theoretical brushed DC motor model.
%   c = DCMotorModel(p), where p is from DCMotorPresets or the GUI.
%   All returned dynamic quantities use SI units unless field names say otherwise.
%
% Assumptions intentionally match the MIE 443 browser motor designer:
%  - two-pole ideal radial-field permanent-magnet machine
%  - infinite-permeability iron, no magnetic saturation/leakage/brush losses
%  - ideal gear reduction, constant specified gear efficiency
%  - copper resistance and magnet strength evaluated at chosen p.T
%  - rotor cylinder and flywheel disk are simplified inertia shapes
%  - electrical and mechanical parameters are not thermally coupled
%   - both thermal nodes start at 25 C; parameter evaluation uses p.T
%
% Educational demonstration ONLY, not an empirical motor specification.

names = {'N','dw','m','d','l','mat','hm','g','T','V','Icmd','drive', ...
    'b','Ng','eta','rL','tL','tauL'};
for q = 1:numel(names)
    assert(isfield(p,names{q}), 'Missing parameter p.%s',names{q});
end
numeric = {'N','dw','d','l','hm','g','T','V','Icmd','b','Ng','eta','rL','tL','tauL'};
for q=1:numel(numeric)
    v=p.(numeric{q});
    assert(isscalar(v)&&isnumeric(v)&&isfinite(v), 'Invalid p.%s',numeric{q});
end
assert(all([p.N,p.dw,p.d,p.l,p.hm,p.g,p.V,p.Icmd,p.Ng,p.eta]>0) && ...
    all([p.b,p.rL,p.tL,p.tauL]>=0) && p.eta<=100 && ...
    any(p.m==[1 3 5 7]),'Invalid motor design values');

switch lower(char(p.mat))
    case 'ferrite'
        M=struct('Br',0.40,'alpha',-0.0020,'mur',1.05,'rho',4900,'cp',800);
    case 'ndfeb'
        M=struct('Br',1.25,'alpha',-0.0012,'mur',1.05,'rho',7500,'cp',440);
    otherwise
        error('Magnet must be Ferrite or NdFeB.');
end
mm=1e-3; d=p.d*mm; ell=p.l*mm; dw=p.dw*mm; hm=p.hm*mm; gap=p.g*mm;
mu0=4*pi*1e-7; rhoCu=1.72e-8; a=2; if p.m==1,a=1;end
Br=M.Br*(1+M.alpha*(p.T-20));
B=Br*hm/(hm+M.mur*gap);
Aw=pi*dw^2/4;
lengthPerTurn=2*ell+2*d;
R20=rhoCu*p.N*lengthPerTurn/(a^2*Aw);
R=R20*(1+0.00393*(p.T-20));
Kt=(2/pi)*p.N*B*ell*d/a;
L=mu0*p.N^2*ell*d/(2*a^2*(gap+hm/M.mur));
fill=2*p.N*Aw/(0.45*pi*d^2/4);
Jr=(pi/32)*7800*ell*d^4;
% Solid steel flywheel on the gearhead output shaft (rho=7850 kg/m^3).
% Inertia is calculated from the same disk geometry as the displayed mass.
flyR=p.rL*mm; flyT=p.tL*mm; rhoFly=7850;
mFly=rhoFly*pi*flyR^2*flyT;
JL=0.5*mFly*flyR^2;
Ng=p.Ng; eta=p.eta/100; J=Jr+JL/Ng^2;
b=p.b*1e-6;
loadMotor=(p.tauL*1e-3)/(Ng*eta);
currentMode=strcmpi(char(p.drive),'Current');
stallI=p.V/R;
if currentMode,stallI=min(stallI,p.Icmd);end
stallTau=Kt*stallI;

% Steady current/speed: ideal command with voltage compliance.
% For a constant opposing load, the ideal shaft is stationary if the
% available starting torque is insufficient. Reverse motion is omitted.
[w0,i0,reg0]=localSteady(0,stallTau,stallI,Kt,p.V,R,b,currentMode,p.Icmd);
[wss,iss,region]=localSteady(loadMotor,stallTau,stallI,Kt,p.V,R,b,currentMode,p.Icmd);
Vterminal=R*iss+Kt*wss;
outputSpeed=wss/Ng;
Pout=p.tauL*1e-3*outputSpeed;
Pin=Vterminal*iss;
eff=0; if Pin>0,eff=Pout/Pin;end
Pcu=iss^2*R; Pfr=b*wss^2;

% Simplified two-node thermal network: winding/rotor -> housing -> ambient.
% Conductances approximate natural convection; these are illustrative.
wall=max(.8*mm,.08*d);
Dout=d+2*gap+2*hm+2*wall; Lout=ell+.5*d+4*mm;
areaSurface=pi*Dout*Lout+.5*pi*Dout^2;
Hout=1.32*(50/Dout)^.25+6;  % reference Delta T=50 K; Dout in m
Hin=40;
areaInner=pi*d*(ell+d);
R1=1/(Hin*areaInner);
R2=1/(Hout*areaSurface);
magR1=d/2+gap; magR2=magR1+hm;
mRotor=7800*pi*d^2/4*ell;
mCopper=8900*p.N*lengthPerTurn*Aw;
mMag=M.rho*(2/3)*pi*(magR2^2-magR1^2)*ell;
mHousing=7850*pi*((Dout/2)^2-(Dout/2-wall)^2)*Lout;
Cw=385*mCopper+460*mRotor;
Ch=460*mHousing+M.cp*mMag;
Twss=25+(Pcu+Pfr)*R2+Pcu*R1;
Thss=25+(Pcu+Pfr)*R2;
Athermal=[-1/(Cw*R1), 1/(Cw*R1); ...
    1/(Ch*R1), -(1/R1+1/R2)/Ch];
thermalPoles=eig(Athermal);
tauThermal=-1/max(real(thermalPoles));

% Voltage-driven poles and friction-inclusive reduced-order time constant.
A=[-R/L -Kt/L;Kt/J -b/J];
poles=eig(A);
tauE=L/R;
tauEff=J/(b+Kt^2/R);
tauDatasheet=R*J/Kt^2;
Nmatch=sqrt(JL/Jr);
r=(p.tauL*1e-3)/(eta*stallTau);
Nacc=r+sqrt(r^2+JL/Jr);
aStart=max(0,(stallTau-loadMotor)/J)/Ng;

% Torque-speed curves parametric in speed; descending X order is reversed
% for plotting/interpolating from zero output torque to stall torque.
W=linspace(w0,0,301);
Ic=(p.V-Kt*W)/R;
if currentMode,Ic=min(Ic,p.Icmd);end
Tau=(Kt*Ic-b*W)*Ng*eta;
Power=Tau.*(W/Ng);
Vmot=R*Ic+Kt*W;
Efficiency=zeros(size(Power));
valid=(Vmot.*Ic)>0;
Efficiency(valid)=Power(valid)./(Vmot(valid).*Ic(valid));
[Tx,order]=sort(Tau*1e3);

c=struct('p',p,'B',B,'Br',Br,'R',R,'R20',R20,'L',L,'Kt',Kt,...
    'Ke',Kt,'Aw',Aw,'fill',fill,'Jr',Jr,'JL',JL,'mFly',mFly,'J',J,'b',b,'Ng',Ng,...
    'eta',eta,'loadMotor',loadMotor,'currentMode',currentMode,...
    'stallI',stallI,'stallTau',stallTau,'stallOut',stallTau*Ng*eta,...
    'w0',w0,'i0',i0,'reg0',reg0,'wss',wss,'iss',iss,'region',region,...
    'Vterminal',Vterminal,'Pout',Pout,'Pin',Pin,'eff',eff,'Pcu',Pcu,'Pfr',Pfr,...
    'JloadReflected',JL/Ng^2,'tauE',tauE,'tauEff',tauEff,...
    'tauDatasheet',tauDatasheet,'poles',poles,'aStart',aStart,...
    'Nmatch',Nmatch,'Nacc',Nacc,'km',Kt/sqrt(R),...
    'mass',mRotor+mMag+mCopper+mHousing,'Dout',Dout,'Lout',Lout,...
    'R1',R1,'R2',R2,'Cw',Cw,'Ch',Ch,'Athermal',Athermal,...
    'tauThermal',tauThermal,'Twss',Twss,'Thss',Thss,...
    'curTorque',Tx,'curSpeed',(W(order)/Ng)*60/(2*pi),...
    'curCurrent',Ic(order),'curPower',Power(order),...
    'curEff',100*Efficiency(order));
end

function [w,i,reg]=localSteady(torque,stallTau,stallI,Kt,V,R,b,currentMode,Icmd)
% Solves the ideal motor electrical/mechanical balance at a load.
if torque>=stallTau
    w=0;i=stallI;reg='Stalled';return
end
wv=(Kt*V/R-torque)/(b+Kt^2/R);
iv=(V-Kt*wv)/R;
if ~currentMode || iv<=Icmd
    w=max(0,wv);i=iv;reg='Voltage';
elseif b>0
    w=max(0,(Kt*Icmd-torque)/b);
    i=Icmd;reg='Current';
else
    % With zero b there is no current-limited steady state below compliance.
    w=max(0,wv);i=iv;reg='Voltage';
end
end


% =======================================================================
% LOCAL HELPER: DCMotorResponse.m
% Included so the GUI runs without extra files or MATLAB path setup.
% =======================================================================
function s=DCMotorResponse(c)
% DCMotorResponse  Motor electrical/mechanical and two-node thermal trajectory.
% Voltage mode: exact constant-input state transitions of the coupled 2nd-order
% linear equations, with an ideal non-backdriving stop at omega=0.
% Current mode: ideal instantaneous current regulation, subject to the
% voltage-compliance ceiling (inductance excluded only in current mode).
% Magnetic and electrical parameters are frozen at the input T; thermal
% results compare time scales, not calibrated maximum safe temperatures.

p=c.p; J=c.J; b=c.b; k=c.Kt; tload=c.loadMotor;
pSlow=real(c.poles); pSlow=pSlow(pSlow<0);
if isempty(pSlow), tMech=20; else,tMech=1/min(abs(pSlow));end
if c.currentMode
    % Current-control ramp time applies only while the command is feasible.
    ws=max(0,(p.V-c.R*p.Icmd)/k);
    if ws>0 && k*p.Icmd>tload
        tMech=max(tMech,J/max(b,1e-15));
    end
    if ws>0 && (k*p.Icmd-tload)>0
        tReach=J*ws/(k*p.Icmd-tload);
        if b>0 && (k*p.Icmd-tload)/b>ws
            tReach=-(J/b)*log1p(-ws*b/(k*p.Icmd-tload));
        end
        if isfinite(tReach),tMech=min(tMech,tReach+7*c.tauEff);end
    end
end
Tspeed=min(2*3600,max(.025,7*max([tMech,c.tauE,c.tauEff])));
Tthermal=min(24*3600,max(Tspeed,7*c.tauThermal));
% Nonuniform samples resolve fast electrical and slow mechanical/thermal effects.
small=max(1e-8,min([c.tauE,c.tauEff,c.tauThermal])*0.01);
logSpeed=logspace(log10(small),log10(Tspeed),180);
logTherm=logspace(log10(small),log10(Tthermal),130);
times=unique([0,linspace(0,Tspeed,480),logSpeed,linspace(0,Tthermal,470),logTherm,Tspeed,Tthermal]);
nt=numel(times); current=zeros(1,nt); omega=zeros(1,nt);
Tw=zeros(1,nt); Th=zeros(1,nt); Tw(1)=25; Th(1)=25; % Ambient initial thermal state
A=[-c.R/c.L -k/c.L; k/J -b/J];
B=[p.V/c.L;-tload/J];
x=[0;0];
Q=c.Athermal;
for n=2:nt
    dt=times(n)-times(n-1);
    if ~c.currentMode
        e=expm(A*dt);
        % Exact second-order transition for constant voltage and load torque.
        % xnew = xss + exp(A dt) * (x - xss).
        xss=-(A\B);
        xn=xss+e*(x-xss);
        if xn(2)<0
            % Non-backdriving shaft. While held, current approaches V/R.
            xn=[p.V/c.R+(x(1)-p.V/c.R)*exp(-dt*c.R/c.L);0];
        elseif x(2)==0 && x(1)*k<=tload
            % Improve release accuracy in steps which straddle breakaway.
            iRelease=tload/k;
            iInf=p.V/c.R;
            if iRelease<iInf
                release=-c.tauE*log(max(realmin,(iInf-iRelease)/(iInf-x(1))));
                if release>0 && release<dt
                    x0=[iRelease;0];
                    xn=xss+expm(A*(dt-release))*(x0-xss);
                    xn(2)=max(0,xn(2));
                end
            end
        end
        x=xn;
    else
        % Quasi-static current mode; switch when the requested current would
        % require more voltage than the supply can provide.
        w=x(2); ws=(p.V-c.R*p.Icmd)/k;
        h=dt;
        if ws>0 && w<ws
            aa=k*p.Icmd-tload;
            if aa<=0
                wn=0;
            elseif b>0
                eq=aa/b; wn=max(0,eq+(w-eq)*exp(-b*h/J));
            else
                wn=max(0,w+aa*h/J);
            end
            if wn>ws
                if b>0
                    eq=aa/b;
                    tc=-(J/b)*log(max(realmin,(ws-eq)/(w-eq)));
                else
                    tc=J*(ws-w)/aa;
                end
                tc=max(0,min(h,tc));
                wInf=(k*p.V/c.R-tload)/(b+k^2/c.R);
                wn=wInf+(ws-wInf)*exp(-(h-tc)/c.tauEff);
            end
        else
            wInf=(k*p.V/c.R-tload)/(b+k^2/c.R);
            wn=max(0,wInf+(w-wInf)*exp(-h/c.tauEff));
        end
        x=[min(p.Icmd,(p.V-k*wn)/c.R);max(0,wn)];
        if x(2)==0,x(1)=min(p.Icmd,p.V/c.R);end
    end
    current(n)=x(1); omega(n)=x(2);
    % Two-node heating: winding copper loss, rotor friction deposited in case.
    avgCu=.5*(current(n-1)^2+current(n)^2)*c.R;
    avgF=.5*(omega(n-1)^2+omega(n)^2)*b;
    heat=[avgCu/c.Cw;avgF/c.Ch];
    steady=-Q\heat;
    prev=[Tw(n-1)-25;Th(n-1)-25];
    next=steady+expm(Q*dt)*(prev-steady);
    Tw(n)=25+next(1);Th(n)=25+next(2);
end
sel=times<=Tspeed+1e-12;
s=struct('t',times(sel),'rpm',omega(sel)/c.Ng*60/(2*pi),...
    'current',current(sel),'wMotor',omega(sel),'Tspeed',Tspeed,...
    'thermalT',times,'Tw',Tw,'Th',Th,'Tthermal',Tthermal,...
    'speedConverged',abs(omega(find(sel,1,'last'))-c.wss) < .01*max(1,c.wss),...
    'Tconverged',abs(Tw(end)-c.Twss)<.02*max(1,abs(c.Twss-25)),...
    'peakCurrent',max(abs(current)), 'peakWindingTemperature',max(Tw),...
    'cappedSpeed',Tspeed>=2*3600,'cappedThermal',Tthermal>=24*3600);
end


% =======================================================================
% LOCAL HELPER: DCMotorSensitivity.m
% Included so the GUI runs without extra files or MATLAB path setup.
% =======================================================================
function [S,rowNames,colNames]=DCMotorSensitivity(p)
% DCMotorSensitivity Normalized log derivatives, +/-1% centered differences.
keys={'N','dw','d','l','hm','g','Ng','rL'};
colNames={'Turns N','Wire d','Rotor d','Length','Magnet h','Gap g','Gear Ng','Flywheel r'};
rowNames={'Torque Kt','Resistance R','Inductance L','Motor km',...
    'Inertia J','Stall torque','No-load rpm','Datasheet tau','Effective tau','Mass'};
S=nan(numel(rowNames),numel(keys));
for j=1:numel(keys)
    key=keys{j};up=p;dn=p;
    up.(key)=p.(key)*1.01;dn.(key)=p.(key)*.99;
    a=DCMotorModel(up);b=DCMotorModel(dn);
    av=[a.Kt,a.R,a.L,a.km,a.J,a.stallOut,a.w0/a.Ng,a.tauDatasheet,a.tauEff,a.mass];
    bv=[b.Kt,b.R,b.L,b.km,b.J,b.stallOut,b.w0/b.Ng,b.tauDatasheet,b.tauEff,b.mass];
    valid=av>0&bv>0;
    S(valid,j)=log(av(valid)./bv(valid))/log(1.01/.99);
end
end


% =======================================================================
% LOCAL HELPER: DCMotorEquations.m
% Included so the GUI runs without extra files or MATLAB path setup.
% =======================================================================
function lines=DCMotorEquations(c,metric)
% DCMotorEquations  Text for the selectable equation inspector.
p=c.p;
switch metric
    case 'Field and magnets'
        lines={'Magnetic field at conductors',...
            'B = Br(T) hm / [hm + mur g]',...
            sprintf('B = %.4f T; Br(T) = %.4f T',c.B,c.Br),...
            'Iron is assumed infinitely permeable; no leakage or saturation.'};
    case 'Torque and back EMF'
        lines={'Average torque / back-EMF constants',...
            'Kt = (2/pi) N B l d / a; Ke = Kt (SI)',...
            sprintf('Kt = Ke = %.5g N m/A = V s/rad; paths a = %d',c.Kt,2*(p.m>1)+(p.m==1)),...
            'Average commutation factor; ignores torque ripple and brush losses.'};
    case 'Winding resistance'
        lines={'Copper resistance at chosen winding temperature',...
            'R = rhoCu(T) N (2l+2d) / (a^2 Aw)',...
            sprintf('R = %.5g ohm; wire = %.3f mm; turns = %g',c.R,p.dw,p.N),...
            'Ignores brush resistance; winding feasibility indicated separately.'};
    case 'Inductance'
        lines={'Simplified magnetic-circuit estimate',...
            'L = mu0 N^2 l d / [2 a^2 (g + hm/mur)]',...
            sprintf('L = %.5g mH; electrical tau = %.5g ms',c.L*1e3,c.tauE*1e3),...
            'Inductance estimate is not validated against a specific motor.'};
    case 'Inertia and gearing'
        lines={'Flywheel: solid steel disk at GEARBOX OUTPUT; rho = 7850 kg/m^3',...
            'mFly = rho pi rL^2 tL; JL = 0.5 mFly rL^2',...
            sprintf('mass = %.4g g; JL at output = %.4g g cm^2',c.mFly*1e3,c.JL*1e7),...
            sprintf('Ng=%.4g: JL seen by motor = JL/Ng^2 = %.4g g cm^2',c.Ng,c.JloadReflected*1e7),...
            sprintf('J total motor = Jr + JL/Ng^2 = %.4g g cm^2',c.J*1e7),...
            sprintf('Acceleration-optimum Ng ~ %.4g; inertia-match Ng ~ %.4g',c.Nacc,c.Nmatch),...
            'Ng = motor speed/output speed. Ignores geartrain inertia and acceleration losses.'};
    case 'Steady speed and torque'
        if strcmp(c.region,'Current')
            formula='w = (Kt Icmd - tauLoadMotor)/b, then /Ng';
        elseif strcmp(c.region,'Stalled')
            formula='Kt istall <= opposing load torque => w = 0';
        else
            formula='w = [Kt V/R - tauLoadMotor] / [b + Kt^2/R], then /Ng';
        end
        lines={'Steady operating point',formula,...
            sprintf('Output speed %.4g rpm; current %.4g A',c.wss/c.Ng*60/(2*pi),c.iss),...
            sprintf('Drive region: %s; torque after gear %.4g mN m',c.region,c.stallOut*1e3)};
    case 'Electrical-mechanical dynamics'
        lines={'Coupled voltage-mode equations',...
            'L di/dt = V - R i - Ke w',...
            'J dw/dt = Kt i - b w - tauLoadMotor',...
            sprintf('tauE = %.4g ms, tauEffective = %.4g ms',c.tauE*1e3,c.tauEff*1e3),...
            'Current mode assumes ideal regulation with voltage compliance.'};
    case 'Efficiency and power'
        lines={'Electrical input, mechanical output, copper loss',...
            'Pin = (R i + Ke w) i; Pout = tauLoad w/Ng',...
            sprintf('At selected load: eta = %.2f%%; Pcu = %.3g W',100*c.eff,c.Pcu),...
            'Maximum curve power is a theoretical instantaneous point.'};
    case 'Thermal network'
        lines={'Two thermal nodes: winding/rotor and housing (start at 25 C)',...
            'Cw dTw/dt = i^2 R - (Tw-Th)/R1',...
            'Ch dTh/dt = b w^2 + (Tw-Th)/R1 - (Th-25)/R2',...
            sprintf('R1 = %.4g, R2 = %.4g K/W; winding steady %.4g C',c.R1,c.R2,c.Twss),...
            'R and Br frozen at evaluation T; heating starts 25 C. NOT a safety predictor.'};
    otherwise
        lines={'Choose a metric to inspect its equation.'};
end
end
