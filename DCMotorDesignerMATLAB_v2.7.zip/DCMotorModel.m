function c = DCMotorModel(p)
% DCMotorModel  Geometry-based theoretical brushed DC motor model.
%   c = DCMotorModel(p), where p is from DCMotorPresets or the GUI.
%   All returned dynamic quantities use SI units unless field names say otherwise.
%
% Assumptions intentionally match the MIE 443 browser motor designer:
%  - two-pole ideal radial-field permanent-magnet machine
%  - infinite-permeability iron, no magnetic saturation/leakage/brush losses
%  - ideal gear reduction, constant specified gear efficiency
%  - copper resistance and magnet strength evaluated at chosen p.T
%  - rotor cylinder and flywheel disk are simplified inertia shapes
%  - electrical and mechanical parameters are not thermally coupled
%  - both thermal nodes start at 25 C; parameter evaluation uses p.T
%
% Educational demonstration ONLY, not an empirical motor specification.

names = {'N','dw','m','d','l','mat','hm','g','T','V','Icmd','drive', ...
    'b','Ng','eta','rL','tL','tauL'};
for q = 1:numel(names)
    assert(isfield(p,names{q}), 'Missing parameter p.%s',names{q});
end
numeric = {'N','dw','d','l','hm','g','T','V','Icmd','b','Ng','eta','rL','tL','tauL'};
for q=1:numel(numeric)
    v=p.(numeric{q});
    assert(isscalar(v)&&isnumeric(v)&&isfinite(v), 'Invalid p.%s',numeric{q});
end
assert(all([p.N,p.dw,p.d,p.l,p.hm,p.g,p.V,p.Icmd,p.Ng,p.eta]>0) && ...
    all([p.b,p.rL,p.tL,p.tauL]>=0) && p.eta<=100 && ...
    any(p.m==[1 3 5 7]),'Invalid motor design values');

switch lower(char(p.mat))
    case 'ferrite'
        M=struct('Br',0.40,'alpha',-0.0020,'mur',1.05,'rho',4900,'cp',800);
    case 'ndfeb'
        M=struct('Br',1.25,'alpha',-0.0012,'mur',1.05,'rho',7500,'cp',440);
    otherwise
        error('Magnet must be Ferrite or NdFeB.');
end
mm=1e-3; d=p.d*mm; ell=p.l*mm; dw=p.dw*mm; hm=p.hm*mm; gap=p.g*mm;
mu0=4*pi*1e-7; rhoCu=1.72e-8; a=2; if p.m==1,a=1;end
Br=M.Br*(1+M.alpha*(p.T-20));
B=Br*hm/(hm+M.mur*gap);
Aw=pi*dw^2/4;
lengthPerTurn=2*ell+2*d;
R20=rhoCu*p.N*lengthPerTurn/(a^2*Aw);
R=R20*(1+0.00393*(p.T-20));
Kt=(2/pi)*p.N*B*ell*d/a;
L=mu0*p.N^2*ell*d/(2*a^2*(gap+hm/M.mur));
fill=2*p.N*Aw/(0.45*pi*d^2/4);
Jr=(pi/32)*7800*ell*d^4;
% Solid steel flywheel on the gearhead output shaft (rho=7850 kg/m^3).
% Inertia is calculated from the same disk geometry as the displayed mass.
flyR=p.rL*mm; flyT=p.tL*mm; rhoFly=7850;
mFly=rhoFly*pi*flyR^2*flyT;
JL=0.5*mFly*flyR^2;
Ng=p.Ng; eta=p.eta/100; J=Jr+JL/Ng^2;
b=p.b*1e-6;
loadMotor=(p.tauL*1e-3)/(Ng*eta);
currentMode=strcmpi(char(p.drive),'Current');
stallI=p.V/R;
if currentMode,stallI=min(stallI,p.Icmd);end
stallTau=Kt*stallI;

% Steady current/speed: ideal command with voltage compliance.
% For a constant opposing load, the ideal shaft is stationary if the
% available starting torque is insufficient. Reverse motion is omitted.
[w0,i0,reg0]=localSteady(0,stallTau,stallI,Kt,p.V,R,b,currentMode,p.Icmd);
[wss,iss,region]=localSteady(loadMotor,stallTau,stallI,Kt,p.V,R,b,currentMode,p.Icmd);
Vterminal=R*iss+Kt*wss;
outputSpeed=wss/Ng;
Pout=p.tauL*1e-3*outputSpeed;
Pin=Vterminal*iss;
eff=0; if Pin>0,eff=Pout/Pin;end
Pcu=iss^2*R; Pfr=b*wss^2;

% Simplified two-node thermal network: winding/rotor -> housing -> ambient.
% Conductances approximate natural convection; these are illustrative.
wall=max(.8*mm,.08*d);
Dout=d+2*gap+2*hm+2*wall; Lout=ell+.5*d+4*mm;
areaSurface=pi*Dout*Lout+.5*pi*Dout^2;
Hout=1.32*(50/Dout)^.25+6; % 50 K reference rise, Dout in meters
Hin=40;
areaInner=pi*d*(ell+d);
R1=1/(Hin*areaInner);
R2=1/(Hout*areaSurface);
magR1=d/2+gap; magR2=magR1+hm;
mRotor=7800*pi*d^2/4*ell;
mCopper=8900*p.N*lengthPerTurn*Aw;
mMag=M.rho*(2/3)*pi*(magR2^2-magR1^2)*ell;
mHousing=7850*pi*((Dout/2)^2-(Dout/2-wall)^2)*Lout;
Cw=385*mCopper+460*mRotor;
Ch=460*mHousing+M.cp*mMag;
Twss=25+(Pcu+Pfr)*R2+Pcu*R1;
Thss=25+(Pcu+Pfr)*R2;
Athermal=[-1/(Cw*R1), 1/(Cw*R1); ...
    1/(Ch*R1), -(1/R1+1/R2)/Ch];
thermalPoles=eig(Athermal);
tauThermal=-1/max(real(thermalPoles));

% Voltage-driven poles and friction-inclusive reduced-order time constant.
A=[-R/L -Kt/L;Kt/J -b/J];
poles=eig(A);
tauE=L/R;
tauEff=J/(b+Kt^2/R);
tauDatasheet=R*J/Kt^2;
Nmatch=sqrt(JL/Jr);
r=(p.tauL*1e-3)/(eta*stallTau);
Nacc=r+sqrt(r^2+JL/Jr);
aStart=max(0,(stallTau-loadMotor)/J)/Ng;

% Torque-speed curves parametric in speed; descending X order is reversed
% for plotting/interpolating from zero output torque to stall torque.
W=linspace(w0,0,301);
Ic=(p.V-Kt*W)/R;
if currentMode,Ic=min(Ic,p.Icmd);end
Tau=(Kt*Ic-b*W)*Ng*eta;
Power=Tau.*(W/Ng);
Vmot=R*Ic+Kt*W;
Efficiency=zeros(size(Power));
valid=(Vmot.*Ic)>0;
Efficiency(valid)=Power(valid)./(Vmot(valid).*Ic(valid));
[Tx,order]=sort(Tau*1e3);

c=struct('p',p,'B',B,'Br',Br,'R',R,'R20',R20,'L',L,'Kt',Kt,...
    'Ke',Kt,'Aw',Aw,'fill',fill,'Jr',Jr,'JL',JL,'mFly',mFly,'J',J,'b',b,'Ng',Ng,...
    'eta',eta,'loadMotor',loadMotor,'currentMode',currentMode,...
    'stallI',stallI,'stallTau',stallTau,'stallOut',stallTau*Ng*eta,...
    'w0',w0,'i0',i0,'reg0',reg0,'wss',wss,'iss',iss,'region',region,...
    'Vterminal',Vterminal,'Pout',Pout,'Pin',Pin,'eff',eff,'Pcu',Pcu,'Pfr',Pfr,...
    'JloadReflected',JL/Ng^2,'tauE',tauE,'tauEff',tauEff,...
    'tauDatasheet',tauDatasheet,'poles',poles,'aStart',aStart,...
    'Nmatch',Nmatch,'Nacc',Nacc,'km',Kt/sqrt(R),...
    'mass',mRotor+mMag+mCopper+mHousing,'Dout',Dout,'Lout',Lout,...
    'R1',R1,'R2',R2,'Cw',Cw,'Ch',Ch,'Athermal',Athermal,...
    'tauThermal',tauThermal,'Twss',Twss,'Thss',Thss,...
    'curTorque',Tx,'curSpeed',(W(order)/Ng)*60/(2*pi),...
    'curCurrent',Ic(order),'curPower',Power(order),...
    'curEff',100*Efficiency(order));
end

function [w,i,reg]=localSteady(torque,stallTau,stallI,Kt,V,R,b,currentMode,Icmd)
% Solves the ideal motor electrical/mechanical balance at a load.
if torque>=stallTau
    w=0;i=stallI;reg='Stalled';return
end
wv=(Kt*V/R-torque)/(b+Kt^2/R);
iv=(V-Kt*wv)/R;
if ~currentMode || iv<=Icmd
    w=max(0,wv);i=iv;reg='Voltage';
elseif b>0
    w=max(0,(Kt*Icmd-torque)/b);
    i=Icmd;reg='Current';
else
    % With zero b there is no current-limited steady state below compliance.
    w=max(0,wv);i=iv;reg='Voltage';
end
end
