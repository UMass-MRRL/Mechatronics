function test_DCMotorDesigner()
% Runs in MATLAB, no Simulink required.
% Numerical checks are invariants, not validation against hardware.
for nm={'Hobby','N20','Neo'}
    p=DCMotorPresets(nm{1}); c=DCMotorModel(p);
    assert(all(isfinite([c.Kt,c.R,c.L,c.J,c.wss,c.Twss])));
    assert(abs(c.Kt-c.Ke)<1e-12);
    assert(abs(c.J-c.Jr-c.JL/c.Ng^2)<1e-9*max(c.J,1e-12));
    assert(c.fill>0 && c.stallI>0 && c.stallOut>0);
    s=DCMotorResponse(c);
    assert(all(isfinite([s.rpm,s.current,s.Tw,s.Th])));
    assert(min(s.rpm)>-1e-8);       % no backdrive for positive opposing torque
    assert(s.speedConverged || s.cappedSpeed);
    assert(all(diff(s.t)>0));
    fprintf('OK preset: %s; no-load %8.1f rpm; loaded %8.1f rpm\n',...
        nm{1},c.w0/c.Ng*60/(2*pi),c.wss/c.Ng*60/(2*pi));
end
% Independent reference values produced by the published HTML motor equations.
% These are numerical equivalence checks, not validation against real motors.
ref=[.33702127659574466,.010298611602691904,1.7578215100833594,0.0010780341769594931;...
     .32727272727272727,.001895969431160179,4.93494097724114,.0004300087399070592;...
     1.057446808510638,.035544513656513024,.47090580938367743,.0005929187973277212];
keys={'Hobby','N20','Neo'};
for k=1:3
    c=DCMotorModel(DCMotorPresets(keys{k}));
    v=[c.B,c.Kt,c.R,c.L];
    assert(all(abs(v-ref(k,:))<1e-10*max(abs(ref(k,:)),1e-6)));
end
% Physical scaling: varying N at fixed wire diameter changes R and Kt.
p=DCMotorPresets('Hobby'); a=DCMotorModel(p);p.N=p.N*2;b=DCMotorModel(p);
assert(abs(b.Kt/a.Kt-2)<1e-10);
assert(abs(b.R/a.R-2)<1e-10);
% Gear load reflection, and current-limit behavior.
p=DCMotorPresets('N20');p.drive='Current';p.Icmd=.08;p.tauL=2;
c=DCMotorModel(p);assert(c.stallI<=.0800001);
s=DCMotorResponse(c);assert(all(isfinite(s.rpm)));
% Stall must stay at zero speed even though current rises.
p=DCMotorPresets('Hobby');p.tauL=3000;
c=DCMotorModel(p);s=DCMotorResponse(c);
assert(strcmp(c.region,'Stalled'));
assert(max(abs(s.rpm))<1e-6);
% Magnet fractional gap sensitivity same when mur,h fixed.
p=DCMotorPresets('Hobby');a=DCMotorModel(p);p.g=2;b=DCMotorModel(p);
p.mat='NdFeB';d=DCMotorModel(p);p.g=.5;e=DCMotorModel(p);
assert(abs((b.B/a.B)-(d.B/e.B))<1e-12);
% Local sensitivities are dimensionless and geometry scaling holds.
p=DCMotorPresets('Hobby');[S,~,~]=DCMotorSensitivity(p);
assert(abs(S(1,1)-1)<.01);
% Reference-50-K housing convection, plus ambient initial temperature.
p=DCMotorPresets('Hobby');c=DCMotorModel(p);
Aout=pi*c.Dout*c.Lout+.5*pi*c.Dout^2;
hActual=1/(c.R2*Aout);
hExpected=1.32*(50/c.Dout)^.25+6;
assert(abs(hActual-hExpected)/hExpected<1e-10, ...
    'Convection regression: 50 K, not 0.050 K');
p.T=120;c=DCMotorModel(p);s=DCMotorResponse(c);
assert(abs(s.Tw(1)-25)<1e-10 && abs(s.Th(1)-25)<1e-10, ...
    'Thermal initial temperature must be ambient 25 C');
assert(s.Tthermal<=24*3600+1e-9);
fprintf('All DC motor numerical tests passed. Native GUI and Simulink require MATLAB testing.\n');
end
