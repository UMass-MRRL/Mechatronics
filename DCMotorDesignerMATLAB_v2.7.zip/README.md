# DC Motor Designer for MATLAB v2.7

Run `DCMotorDesignerMATLAB` in base MATLAB. The GUI is self-contained in that `.m` file. Simulink is optional and is used only for `build_DCMotor_Simulink_Advanced`.

Corrections: the housing convection reference is **50 K**, not 0.050 K; heating begins at 25 °C; thermal plots extend to 24 h if required; rapid motor transients play over about 8 seconds; preset reset and reference clearing now work; CSV includes all model inputs and outputs. The coil count 3/5/7 changes the drawing, but not the average-performance model.

Use `test_DCMotorDesigner` for numerical checks and `test_MATLAB_GUI_v2_7` for a native GUI smoke test. The latter must be run on a computer with MATLAB; it has not been executed in this environment. Educational use only.
