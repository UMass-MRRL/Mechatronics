# MIE 443 DC Motor Designer MATLAB v2.3

## Quick start: ONE MATLAB FILE

This version fixes two reported MATLAB startup errors:

```
Unrecognized function or variable 'DCMotorPresets'.
Error in DCMotorDesignerMATLAB (line 11)

Unrecognized property 'Units' for class 'matlab.ui.control.TextArea'.
```

**The GUI is self-contained and now uses a responsive grid layout for the metrics text area.** The five required helpers (`DCMotorPresets`,
`DCMotorModel`, `DCMotorResponse`, `DCMotorSensitivity`, and
`DCMotorEquations`) are all included as **local functions in
`DCMotorDesignerMATLAB.m`**. You can run it after downloading only that
single file.

1. Download `DCMotorDesignerMATLAB.m` to a folder on your computer.
2. In MATLAB, set **Current Folder** to the folder containing that file.
3. Type:

   ```matlab
   clear DCMotorDesignerMATLAB
   DCMotorDesignerMATLAB
   ```

`clear` is optional, but helps when overwriting a prior version in the
same MATLAB session.

If you still see an error, check which file MATLAB is executing:

```matlab
which DCMotorDesignerMATLAB -all
```

The correct path should point to this new `DCMotorDesignerMATLAB.m`.
If it points to an older file, change the MATLAB Current Folder or remove
the old location from the path.

**Requires base MATLAB with App Designer graphics support.** Simulink is not
required for the interactive GUI. Recommended MATLAB R2023b or newer. The
native MATLAB interface has **not been executed in this authoring environment**,
so report any remaining GUI-specific errors with the line number.

## Optional: Simulink and numerical testing

The ZIP includes separate copies of the model functions so the independent
Simulink model generator and numerical test script can call them. They are
**not required for the GUI**.

For an editable plant block diagram, with Simulink installed:

```matlab
build_DCMotor_Simulink_Advanced
```

To run numerical consistency tests:

```matlab
test_DCMotorDesigner
```

These optional commands do require **all `.m` files from the ZIP together**
in the MATLAB Current Folder or on its path. The standalone GUI resolves its
own local helper copies first. Simulink is an intentionally reduced
voltage-mode dynamics model, not a full GUI equivalent.

## Model and educational disclaimer

**EDUCATIONAL USE ONLY.** This is a simplified, first-principles brushed DC
motor teaching simulator. Numerical values are model predictions and have not
been experimentally validated for any named commercial motor. The physical
drawings are schematics. It is **not** a reliable basis for component selection,
thermal ratings, electrical safety decisions, or real motor design.

The model assumes an ideal magnetic circuit, simplified motor geometries,
constant gearbox efficiency, lumped thermal nodes, and no brush loss or
iron saturation. The voltage-drive model retains inductance and signed
armature current; the ideal-current-mode approximation omits current-loop
transients.

## Contents

- `DCMotorDesignerMATLAB.m` : **one-file GUI**, contains all its own helper functions.
- `DCMotorPresets.m` : optional external helper for testing/model generator.
- `DCMotorModel.m` : optional external model helper.
- `DCMotorResponse.m` : optional external transient helper.
- `DCMotorSensitivity.m` : optional external sensitivity helper.
- `DCMotorEquations.m` : optional external equation-text helper.
- `build_DCMotor_Simulink_Advanced.m` : optional Simulink generator.
- `test_DCMotorDesigner.m` : optional numerical checks.

## v2.3 MATLAB UI correction (October 21, 2026)

- Removed the invalid `metrics.Units='normalized'` assignment from the `uitextarea`.
- Replaced fixed pixel text positioning with `uigridlayout` inside the metrics panel.
- Normalized several `GridLayout.Padding` assignments to documented four-value vectors.
- No App Designer toolbox is required: `uifigure`, `uitextarea`, `uislider`, and
  `uigridlayout` are provided by base MATLAB.

**Verification limitation:** Changes were checked statically against MathWorks UI
API documentation and source layout. This environment cannot run MATLAB, so
full native GUI startup and animation remain unverified.

## Classic torque-speed diagram (v2.3)

On the **Motor & Performance** tab, the large upper performance chart now
plots **available output torque (mN·m) vertically** versus **output speed
(rpm) horizontally**. It marks the idealized stall torque (0 rpm), no-load
speed (0 external torque), and the selected operating point. A pinned reference
design is dashed. With current control, the characteristic can be piecewise;
the curve is not a continuous-duty envelope. The three lower panels continue
to plot current, power, and efficiency versus applied output torque.

This revision preserves the v2.2 model and UI structure, but its modified
MATLAB visualization has not been executed in MATLAB by the preparer.
