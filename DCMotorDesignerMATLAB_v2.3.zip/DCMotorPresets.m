function p = DCMotorPresets(which)
% DCMotorPresets  Parameter sets matching the MIE 443 web motor designer.
if nargin<1,which='Hobby';end
p=struct('drive','Voltage','V',12,'Icmd',2,'N',240,'dw',.25,...
    'm',3,'d',16,'l',25,'mat','Ferrite','hm',3,'g',.5,'T',25,...
    'b',2,'Ng',1,'eta',100,'rL',25,'tL',5,'tauL',10);
switch lower(char(which))
    case {'hobby','12 v ferrite'}
    case {'n20','n20 gearmotor'}
        p.N=260;p.dw=.10;p.d=7;p.l=10;p.hm=1.5;p.g=.3;
        p.V=5;p.Icmd=.5;p.b=.05;p.Ng=100;p.eta=60;
        p.rL=20;p.tL=4;p.tauL=5;
    case {'neo','ndfeb 30 mm'}
        p.N=120;p.dw=.42;p.m=7;p.d=22;p.l=40;p.mat='NdFeB';
        p.hm=3;p.g=.5;p.V=24;p.Icmd=10;p.b=5;p.Ng=1;
        p.eta=100;p.rL=30;p.tL=6;p.tauL=20;
    otherwise
        error('Unknown preset: %s',char(which));
end
end
