function [S,rowNames,colNames]=DCMotorSensitivity(p)
% DCMotorSensitivity Normalized log derivatives, +/-1% centered differences.
keys={'N','dw','d','l','hm','g','Ng','rL'};
colNames={'Turns N','Wire d','Rotor d','Length','Magnet h','Gap g','Gear Ng','Flywheel r'};
rowNames={'Torque Kt','Resistance R','Inductance L','Motor km',...
    'Inertia J','Stall torque','No-load rpm','Datasheet tau','Effective tau','Mass'};
S=nan(numel(rowNames),numel(keys));
for j=1:numel(keys)
    key=keys{j};up=p;dn=p;
    up.(key)=p.(key)*1.01;dn.(key)=p.(key)*.99;
    a=DCMotorModel(up);b=DCMotorModel(dn);
    av=[a.Kt,a.R,a.L,a.km,a.J,a.stallOut,a.w0/a.Ng,a.tauDatasheet,a.tauEff,a.mass];
    bv=[b.Kt,b.R,b.L,b.km,b.J,b.stallOut,b.w0/b.Ng,b.tauDatasheet,b.tauEff,b.mass];
    valid=av>0&bv>0;
    S(valid,j)=log(av(valid)./bv(valid))/log(1.01/.99);
end
end
