function build_DCMotor_Simulink_Advanced(p)
% build_DCMotor_Simulink_Advanced Generate an editable voltage-drive block model.
% Run with Simulink installed:
%    build_DCMotor_Simulink_Advanced
%    build_DCMotor_Simulink_Advanced(DCMotorPresets('N20'))
%
% This is a TEACHING block diagram for the same L/R, Kt/Ke, J, b,
% load reflection and output gearing used by DCMotorModel. It omits the
% GUI's current-mode switching, nonbackdriving stop and thermal network.
if nargin<1 || isempty(p),p=DCMotorPresets('Hobby');end
assert(exist('new_system','file')~=0,'Simulink is required to build the .slx.');
c=DCMotorModel(p);
name='MIE443_DC_Motor_Design';
if bdIsLoaded(name),close_system(name,0);end
new_system(name);open_system(name);

% Source inputs: apply supply at .02s, opposing load at .3 of duration.
T=max(.35,min(30,8*max(c.tauE,c.tauEff)));
add('simulink/Sources/Step','Supply V',[25 100 80 130],...
    'Time',num2str(.02*T,16),'Before','0','After',num2str(p.V,16));
add('simulink/Sources/Step','Output load Nm',[470 350 540 380],...
    'Time',num2str(.3*T,16),'Before','0','After',num2str(p.tauL*1e-3,16));
add('simulink/Math Operations/Gain','Load to motor',[555 350 640 380],...
    'Gain',num2str(1/(c.Ng*c.eta),16));

add('simulink/Math Operations/Sum','Electrical sum',[165 92 199 134],...
    'Inputs','+--');
add('simulink/Math Operations/Gain','Inverse L',[245 96 305 128],...
    'Gain',num2str(1/c.L,16));
add('simulink/Continuous/Integrator','Current i',[340 94 385 131]);
add('simulink/Math Operations/Gain','Resistance R',[250 205 315 237],...
    'Gain',num2str(c.R,16));
add('simulink/Math Operations/Gain','Back EMF Ke',[680 270 755 305],...
    'Gain',num2str(c.Ke,16));

add('simulink/Math Operations/Gain','Torque Kt',[465 97 535 127],...
    'Gain',num2str(c.Kt,16));
add('simulink/Math Operations/Sum','Mechanical sum',[615 93 651 133],...
    'Inputs','+--');
add('simulink/Math Operations/Gain','Inverse J',[697 95 764 128],...
    'Gain',num2str(1/c.J,16));
add('simulink/Continuous/Integrator','Motor omega',[808 97 853 129]);
add('simulink/Math Operations/Gain','Viscous b',[700 195 755 225],...
    'Gain',num2str(c.b,16));
add('simulink/Math Operations/Gain','Output rpm',[890 98 960 128],...
    'Gain',num2str(60/(2*pi*c.Ng),16));
add('simulink/Sinks/Scope','Speed scope',[998 96 1041 134]);
add('simulink/Sinks/Scope','Current scope',[470 20 515 50]);

wire('Supply V/1','Electrical sum/1');
wire('Electrical sum/1','Inverse L/1');
wire('Inverse L/1','Current i/1');
wire('Current i/1','Resistance R/1');
wire('Resistance R/1','Electrical sum/2');
wire('Motor omega/1','Back EMF Ke/1');
wire('Back EMF Ke/1','Electrical sum/3');
wire('Current i/1','Torque Kt/1');
wire('Torque Kt/1','Mechanical sum/1');
wire('Output load Nm/1','Load to motor/1');
wire('Load to motor/1','Mechanical sum/3');
wire('Motor omega/1','Viscous b/1');
wire('Viscous b/1','Mechanical sum/2');
wire('Mechanical sum/1','Inverse J/1');
wire('Inverse J/1','Motor omega/1');
wire('Motor omega/1','Output rpm/1');
wire('Output rpm/1','Speed scope/1');
wire('Current i/1','Current scope/1');

set_param(name,'StopTime',num2str(T,16),'Solver','ode45');
save_system(name,fullfile(pwd,[name,'.slx']));open_system(name);
fprintf('Saved %s.slx.\n',name);
    function add(src,label,pos,varargin)
        add_block(src,[name '/' label],'Position',pos,varargin{:});
    end
    function wire(from,to)
        add_line(name,from,to,'autorouting','on');
    end
end
