function s=DCMotorResponse(c)
% DCMotorResponse  Motor electrical/mechanical and two-node thermal trajectory.
% Voltage mode: exact constant-input state transitions of the coupled 2nd-order
% linear equations, with an ideal non-backdriving stop at omega=0.
% Current mode: ideal instantaneous current regulation, subject to the
% voltage-compliance ceiling (inductance excluded only in current mode).
% Magnetic and electrical parameters are frozen at the input T; thermal
% results compare time scales, not calibrated maximum safe temperatures.

p=c.p; J=c.J; b=c.b; k=c.Kt; tload=c.loadMotor;
pSlow=real(c.poles); pSlow=pSlow(pSlow<0);
if isempty(pSlow), tMech=20; else,tMech=1/min(abs(pSlow));end
if c.currentMode
    % Current-control ramp time applies only while the command is feasible.
    ws=max(0,(p.V-c.R*p.Icmd)/k);
    if ws>0 && k*p.Icmd>tload
        tMech=max(tMech,J/max(b,1e-15));
    end
    if ws>0 && (k*p.Icmd-tload)>0
        tReach=J*ws/(k*p.Icmd-tload);
        if b>0 && (k*p.Icmd-tload)/b>ws
            tReach=-(J/b)*log1p(-ws*b/(k*p.Icmd-tload));
        end
        if isfinite(tReach),tMech=min(tMech,tReach+7*c.tauEff);end
    end
end
Tspeed=min(2*3600,max(.025,7*max([tMech,c.tauE,c.tauEff])));
Tthermal=min(4*3600,max(Tspeed,7*c.tauThermal));
% Nonuniform samples resolve fast electrical and slow mechanical/thermal effects.
small=max(1e-8,min([c.tauE,c.tauEff,c.tauThermal])*0.01);
logSpeed=logspace(log10(small),log10(Tspeed),180);
logTherm=logspace(log10(small),log10(Tthermal),130);
times=unique([0,linspace(0,Tspeed,480),logSpeed,linspace(0,Tthermal,470),logTherm,Tspeed,Tthermal]);
nt=numel(times); current=zeros(1,nt); omega=zeros(1,nt);
Tw=zeros(1,nt); Th=zeros(1,nt); Tw(1)=p.T; Th(1)=p.T;
A=[-c.R/c.L -k/c.L; k/J -b/J];
B=[p.V/c.L;-tload/J];
x=[0;0];
Q=c.Athermal;
for n=2:nt
    dt=times(n)-times(n-1);
    if ~c.currentMode
        e=expm(A*dt);
        % Exact second-order transition for constant voltage and load torque.
        % xnew = xss + exp(A dt) * (x - xss).
        xss=-(A\B);
        xn=xss+e*(x-xss);
        if xn(2)<0
            % Non-backdriving shaft. While held, current approaches V/R.
            xn=[p.V/c.R+(x(1)-p.V/c.R)*exp(-dt*c.R/c.L);0];
        elseif x(2)==0 && x(1)*k<=tload
            % Improve release accuracy in steps which straddle breakaway.
            iRelease=tload/k;
            iInf=p.V/c.R;
            if iRelease<iInf
                release=-c.tauE*log(max(realmin,(iInf-iRelease)/(iInf-x(1))));
                if release>0 && release<dt
                    x0=[iRelease;0];
                    xn=xss+expm(A*(dt-release))*(x0-xss);
                    xn(2)=max(0,xn(2));
                end
            end
        end
        x=xn;
    else
        % Quasi-static current mode; switch when the requested current would
        % require more voltage than the supply can provide.
        w=x(2); ws=(p.V-c.R*p.Icmd)/k;
        h=dt;
        if ws>0 && w<ws
            aa=k*p.Icmd-tload;
            if aa<=0
                wn=0;
            elseif b>0
                eq=aa/b; wn=max(0,eq+(w-eq)*exp(-b*h/J));
            else
                wn=max(0,w+aa*h/J);
            end
            if wn>ws
                if b>0
                    eq=aa/b;
                    tc=-(J/b)*log(max(realmin,(ws-eq)/(w-eq)));
                else
                    tc=J*(ws-w)/aa;
                end
                tc=max(0,min(h,tc));
                wInf=(k*p.V/c.R-tload)/(b+k^2/c.R);
                wn=wInf+(ws-wInf)*exp(-(h-tc)/c.tauEff);
            end
        else
            wInf=(k*p.V/c.R-tload)/(b+k^2/c.R);
            wn=max(0,wInf+(w-wInf)*exp(-h/c.tauEff));
        end
        x=[min(p.Icmd,(p.V-k*wn)/c.R);max(0,wn)];
        if x(2)==0,x(1)=min(p.Icmd,p.V/c.R);end
    end
    current(n)=x(1); omega(n)=x(2);
    % Two-node heating: winding copper loss, rotor friction deposited in case.
    avgCu=.5*(current(n-1)^2+current(n)^2)*c.R;
    avgF=.5*(omega(n-1)^2+omega(n)^2)*b;
    heat=[avgCu/c.Cw;avgF/c.Ch];
    steady=-Q\heat;
    prev=[Tw(n-1)-25;Th(n-1)-25];
    next=steady+expm(Q*dt)*(prev-steady);
    Tw(n)=25+next(1);Th(n)=25+next(2);
end
sel=times<=Tspeed+1e-12;
s=struct('t',times(sel),'rpm',omega(sel)/c.Ng*60/(2*pi),...
    'current',current(sel),'wMotor',omega(sel),'Tspeed',Tspeed,...
    'thermalT',times,'Tw',Tw,'Th',Th,'Tthermal',Tthermal,...
    'speedConverged',abs(omega(find(sel,1,'last'))-c.wss) < .01*max(1,c.wss),...
    'Tconverged',abs(Tw(end)-c.Twss)<.02*max(1,abs(c.Twss-25)),...
    'peakCurrent',max(abs(current)), 'peakWindingTemperature',max(Tw),...
    'cappedSpeed',Tspeed>=2*3600,'cappedThermal',Tthermal>=4*3600);
end
